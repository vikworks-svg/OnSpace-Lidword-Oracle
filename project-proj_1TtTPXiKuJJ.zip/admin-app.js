class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--bg)]">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-[var(--text)] mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function AdminApp() {
  try {
    const [packs, setPacks] = React.useState([]);
    const [showForm, setShowForm] = React.useState(false);
    const [editingPack, setEditingPack] = React.useState(null);
    const [formData, setFormData] = React.useState({
      name: '',
      description: '',
      category: '',
      unlock_requirement: '',
      unlock_type: 'default',
      unlock_value: 0,
      word_count: 0,
      is_active: true,
      sort_order: 1
    });

    React.useEffect(() => {
      loadPacks();
    }, []);

    const loadPacks = async () => {
      try {
        const packsData = await trickleListObjects('vocabulary_pack', 100);
        setPacks(packsData.items.sort((a, b) => a.objectData.sort_order - b.objectData.sort_order));
      } catch (error) {
        console.error('Error loading packs:', error);
      }
    };

    const handleSubmit = async (e) => {
      e.preventDefault();
      try {
        if (editingPack) {
          await trickleUpdateObject('vocabulary_pack', editingPack.objectId, formData);
        } else {
          await trickleCreateObject('vocabulary_pack', formData);
        }
        
        setShowForm(false);
        setEditingPack(null);
        resetForm();
        loadPacks();
      } catch (error) {
        console.error('Error saving pack:', error);
      }
    };

    const handleEdit = (pack) => {
      setEditingPack(pack);
      setFormData(pack.objectData);
      setShowForm(true);
    };

    const handleDelete = async (packId) => {
      if (confirm('Are you sure you want to delete this pack?')) {
        try {
          await trickleDeleteObject('vocabulary_pack', packId);
          loadPacks();
        } catch (error) {
          console.error('Error deleting pack:', error);
        }
      }
    };

    const resetForm = () => {
      setFormData({
        name: '',
        description: '',
        category: '',
        unlock_requirement: '',
        unlock_type: 'default',
        unlock_value: 0,
        word_count: 0,
        is_active: true,
        sort_order: packs.length + 1
      });
    };

    return (
      <div className="min-h-screen bg-[var(--bg)]">
        <header className="border-b border-[var(--border)] bg-[var(--bg-elev)]">
          <div className="max-w-6xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <h1 className="text-xl font-bold text-[var(--text)]">Admin - Vocabulary Management</h1>
              <a href="index.html" className="text-[var(--accent)] hover:underline">← Back to App</a>
            </div>
          </div>
        </header>

        <main className="max-w-6xl mx-auto px-4 py-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold text-[var(--text)]">Vocabulary Packs</h2>
            <button
              onClick={() => {
                resetForm();
                setShowForm(true);
              }}
              className="btn btn-primary"
            >
              <div className="icon-plus text-lg mr-2"></div>
              Add Pack
            </button>
          </div>

          {showForm && (
            <div className="card mb-8">
              <h3 className="text-lg font-semibold text-[var(--text)] mb-4">
                {editingPack ? 'Edit Pack' : 'Add New Pack'}
              </h3>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-[var(--muted)] mb-2">Name</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="input"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-[var(--muted)] mb-2">Category</label>
                    <input
                      type="text"
                      value={formData.category}
                      onChange={(e) => setFormData({...formData, category: e.target.value})}
                      className="input"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--muted)] mb-2">Description</label>
                  <input
                    type="text"
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    className="input"
                    required
                  />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-[var(--muted)] mb-2">Unlock Type</label>
                    <select
                      value={formData.unlock_type}
                      onChange={(e) => setFormData({...formData, unlock_type: e.target.value})}
                      className="input"
                    >
                      <option value="default">Available from start</option>
                      <option value="streak">Day streak required</option>
                      <option value="accuracy">Overall accuracy required</option>
                      <option value="previous_pack">Previous pack completion</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-[var(--muted)] mb-2">Unlock Value</label>
                    <input
                      type="number"
                      value={formData.unlock_value}
                      onChange={(e) => setFormData({...formData, unlock_value: parseInt(e.target.value)})}
                      className="input"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-[var(--muted)] mb-2">Word Count</label>
                    <input
                      type="number"
                      value={formData.word_count}
                      onChange={(e) => setFormData({...formData, word_count: parseInt(e.target.value)})}
                      className="input"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--muted)] mb-2">Unlock Requirement Text</label>
                  <input
                    type="text"
                    value={formData.unlock_requirement}
                    onChange={(e) => setFormData({...formData, unlock_requirement: e.target.value})}
                    className="input"
                    placeholder="e.g., 5 day streak required"
                    required
                  />
                </div>

                <div className="flex gap-4">
                  <button type="submit" className="btn btn-primary">
                    {editingPack ? 'Update Pack' : 'Create Pack'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowForm(false);
                      setEditingPack(null);
                    }}
                    className="btn btn-secondary"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="space-y-4">
            {packs.map((pack, index) => (
              <div key={index} className="card">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-4 mb-2">
                      <h3 className="text-lg font-semibold text-[var(--text)]">{pack.objectData.name}</h3>
                      <span className="px-2 py-1 bg-[var(--border)] text-[var(--muted)] rounded text-xs">
                        {pack.objectData.category}
                      </span>
                      <span className={`px-2 py-1 rounded text-xs ${
                        pack.objectData.is_active ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                      }`}>
                        {pack.objectData.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    
                    <p className="text-[var(--muted)] mb-2">{pack.objectData.description}</p>
                    
                    <div className="flex items-center gap-6 text-sm text-[var(--muted)]">
                      <span>Words: {pack.objectData.word_count}</span>
                      <span>Order: {pack.objectData.sort_order}</span>
                      <span>Unlock: {pack.objectData.unlock_requirement}</span>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleEdit(pack)}
                      className="btn btn-secondary text-sm"
                    >
                      <div className="icon-edit text-sm"></div>
                    </button>
                    <button
                      onClick={() => handleDelete(pack.objectId)}
                      className="btn text-[var(--danger)] hover:bg-[var(--danger)]/10 border-[var(--danger)] text-sm"
                    >
                      <div className="icon-trash text-sm"></div>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    );
  } catch (error) {
    console.error('AdminApp component error:', error);
    return null;
  }
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <AdminApp />
  </ErrorBoundary>
);
