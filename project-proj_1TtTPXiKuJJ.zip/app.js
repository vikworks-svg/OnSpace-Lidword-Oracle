class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--bg)]">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-[var(--text)] mb-4">Something went wrong</h1>
            <p className="text-[var(--muted)] mb-4">We're sorry, but something unexpected happened.</p>
            <button
              onClick={() => window.location.reload()}
              className="btn btn-primary"
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function Dashboard() {
  try {
    const [stats, setStats] = React.useState({
      dayStreak: 0,
      totalWords: 0,
      dueForReview: 0,
      accuracy: 0
    });

    React.useEffect(() => {
      // Initialize data and calculate stats
      initializeData();
      calculateStats().then(setStats);
    }, []);

    const activities = [
      {
        id: 'ditdat',
        title: 'Dit/Dat Dash',
        description: 'Choose the right demonstrative',
        icon: 'zap',
        route: 'ditdat.html',
        primary: true
      },
      {
        id: 'quickfire',
        title: 'De/Het Quickfire',
        description: '60 seconds of article practice',
        icon: 'timer',
        route: 'quickfire.html'
      },
      {
        id: 'challenge',
        title: 'Daily Challenge',
        description: '3 words, 3 tasks each',
        icon: 'target',
        route: 'challenge.html'
      }
    ];

    return (
      <div className="min-h-screen bg-[var(--bg)]" data-name="dashboard" data-file="app.js">
        <Header />
        
        <main className="max-w-6xl mx-auto px-4 py-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <StatTile label="Day Streak" value={stats.dayStreak} />
            <StatTile label="Total Words" value={stats.totalWords} />
            <StatTile label="Due for Review" value={stats.dueForReview} />
            <StatTile label="Accuracy" value={`${stats.accuracy}%`} />
          </div>

          {/* Nemesis Words */}
          <NemesisCard />

          {/* Vocabulary Packs */}
          <VocabularyCard />

          {/* Activity Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {activities.map(activity => (
              <ActivityCard
                key={activity.id}
                title={activity.title}
                description={activity.description}
                icon={activity.icon}
                route={activity.route}
                primary={activity.primary}
              />
            ))}
          </div>

          {/* Hint Card */}
          <HintCard />

          {/* Quick Access */}
          <div className="flex flex-wrap gap-4 justify-center mt-8">
            <button 
              onClick={() => window.location.href = 'lookup.html'}
              className="btn btn-secondary"
            >
              <div className="icon-search text-lg mr-2"></div>
              Lookup
            </button>
            <button 
              onClick={() => window.location.href = 'rules.html'}
              className="btn btn-secondary"
            >
              <div className="icon-book text-lg mr-2"></div>
              Rules
            </button>
          </div>
        </main>
      </div>
    );
  } catch (error) {
    console.error('Dashboard component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <Dashboard />
  </ErrorBoundary>
);