class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--bg)]">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-[var(--text)] mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function DailyChallenge() {
  try {
    const [challengeState, setChallengeState] = React.useState('loading');
    const [words, setWords] = React.useState([]);
    const [currentWordIndex, setCurrentWordIndex] = React.useState(0);
    const [currentTask, setCurrentTask] = React.useState(0);
    const [score, setScore] = React.useState(0);
    const [feedback, setFeedback] = React.useState(null);
    const [proximity, setProximity] = React.useState('NEAR');

    React.useEffect(() => {
      loadDailyChallenge();
    }, []);

    const loadDailyChallenge = async () => {
      try {
        const today = new Date().toISOString().split('T')[0];
        
        // Check if challenge already exists for today
        const challenges = await trickleListObjects('dailyChallenge', 10);
        const todayChallenge = challenges.items.find(c => c.objectData.date === today);
        
        if (todayChallenge && todayChallenge.objectData.completed) {
          setChallengeState('completed');
          return;
        }
        
        let challengeWords;
        if (todayChallenge) {
          // Load existing challenge
          const wordPromises = todayChallenge.objectData.wordIds.map(async (id) => {
            const word = await trickleGetObject('word', id);
            return { ...word.objectData, id: word.objectId };
          });
          challengeWords = await Promise.all(wordPromises);
        } else {
          // Create new challenge
          challengeWords = await getWeightedWords(3, false);
          await trickleCreateObject('dailyChallenge', {
            date: today,
            wordIds: challengeWords.map(w => w.id),
            completed: false,
            completedTasks: 0
          });
        }
        
        setWords(challengeWords);
        setChallengeState('ready');
      } catch (error) {
        console.error('Error loading daily challenge:', error);
        setChallengeState('error');
      }
    };

    const handleAnswer = async (answer) => {
      if (!words[currentWordIndex] || feedback) return;

      const currentWord = words[currentWordIndex];
      let isCorrect = false;

      // Check answer based on current task
      if (currentTask === 0) {
        // Article task
        isCorrect = answer === currentWord.article;
      } else if (currentTask === 1) {
        // Demonstrative task
        const correct = getCorrectDemonstrative(currentWord.article, proximity);
        isCorrect = answer === correct;
      } else {
        // Adjective task (simplified for now)
        isCorrect = true; // TODO: Implement adjective logic
      }

      if (isCorrect) {
        setScore(prev => prev + 1);
      }

      const feedbackText = getRandomFeedback(isCorrect);
      setFeedback({ text: feedbackText, correct: isCorrect });

      await recordAttempt(currentWord.id, 'challenge', isCorrect, answer);

      setTimeout(() => {
        nextTask();
      }, 1800);
    };

    const nextTask = () => {
      setFeedback(null);
      
      if (currentTask < 2) {
        setCurrentTask(prev => prev + 1);
        if (currentTask === 0) {
          setProximity(Math.random() > 0.5 ? 'NEAR' : 'FAR');
        }
      } else if (currentWordIndex < words.length - 1) {
        setCurrentWordIndex(prev => prev + 1);
        setCurrentTask(0);
      } else {
        completeDailyChallenge();
      }
    };

    const completeDailyChallenge = async () => {
      try {
        const today = new Date().toISOString().split('T')[0];
        const challenges = await trickleListObjects('dailyChallenge', 10);
        const todayChallenge = challenges.items.find(c => c.objectData.date === today);
        
        if (todayChallenge) {
          await trickleUpdateObject('dailyChallenge', todayChallenge.objectId, {
            completed: true,
            completedTasks: score
          });
        }
        
        setChallengeState('completed');
      } catch (error) {
        console.error('Error completing challenge:', error);
      }
    };

    const getTaskTitle = () => {
      const tasks = ['Choose Article', 'Choose Demonstrative', 'Choose Adjective'];
      return tasks[currentTask];
    };

    const renderTask = () => {
      const currentWord = words[currentWordIndex];
      if (!currentWord) return null;

      if (currentTask === 0) {
        // Article task
        return (
          <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
            <button
              onClick={() => handleAnswer('de')}
              className="btn btn-secondary text-xl py-4"
              disabled={!!feedback}
            >
              de
            </button>
            <button
              onClick={() => handleAnswer('het')}
              className="btn btn-secondary text-xl py-4"
              disabled={!!feedback}
            >
              het
            </button>
          </div>
        );
      } else if (currentTask === 1) {
        // Demonstrative task
        return (
          <div>
            <div className={`inline-block px-4 py-2 rounded-full text-sm font-medium mb-6 ${
              proximity === 'NEAR' ? 'bg-[var(--bg)] text-[var(--accent)] border border-[var(--accent)]' : 'bg-[var(--bg)] text-[var(--muted)] border border-[var(--muted)]'
            }`}>
              {proximity}
            </div>
            <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
              {['dit', 'dat', 'deze', 'die'].map(option => (
                <button
                  key={option}
                  onClick={() => handleAnswer(option)}
                  className="btn btn-secondary text-lg py-3"
                  disabled={!!feedback}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        );
      } else {
        // Adjective task (simplified)
        return (
          <div className="text-center">
            <p className="text-[var(--muted)] mb-6">Choose the correct adjective form:</p>
            <div className="text-xl mb-6">Dit is ___ boek.</div>
            <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
              <button
                onClick={() => handleAnswer('klein')}
                className="btn btn-secondary text-lg py-3"
                disabled={!!feedback}
              >
                klein
              </button>
              <button
                onClick={() => handleAnswer('kleine')}
                className="btn btn-secondary text-lg py-3"
                disabled={!!feedback}
              >
                kleine
              </button>
            </div>
          </div>
        );
      }
    };

    if (challengeState === 'loading') {
      return (
        <div className="min-h-screen bg-[var(--bg)]">
          <Header />
          <main className="max-w-2xl mx-auto px-4 py-8">
            <div className="card text-center">
              <div className="icon-loader text-2xl text-[var(--accent)] mb-4"></div>
              <p className="text-[var(--text)]">Loading today's challenge...</p>
            </div>
          </main>
        </div>
      );
    }

    if (challengeState === 'completed') {
      return (
        <div className="min-h-screen bg-[var(--bg)]">
          <Header />
          <main className="max-w-2xl mx-auto px-4 py-8">
            <div className="card text-center">
              <div className="w-16 h-16 bg-[var(--accent)] rounded-lg mx-auto mb-6 flex items-center justify-center">
                <div className="icon-check text-2xl text-[var(--accent-ink)]"></div>
              </div>
              <h1 className="text-3xl font-bold text-[var(--text)] mb-4">Challenge Complete!</h1>
              <p className="text-[var(--muted)] mb-8">Come back tomorrow for a new challenge</p>
              <button
                onClick={() => window.location.href = 'index.html'}
                className="btn btn-primary"
              >
                Back to Dashboard
              </button>
            </div>
          </main>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-[var(--bg)]">
        <Header />
        
        {feedback && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="card max-w-md w-full mx-4 text-center">
              <h2 className={`text-2xl font-bold mb-4 ${feedback.correct ? 'text-[var(--accent)]' : 'text-[var(--danger)]'}`}>
                {feedback.text}
              </h2>
              <button onClick={nextTask} className="btn btn-primary">
                Continue
              </button>
            </div>
          </div>
        )}

        <main className="max-w-2xl mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-[var(--text)] mb-2">Daily Challenge</h1>
            <p className="text-[var(--muted)]">Word {currentWordIndex + 1} of {words.length} • Task {currentTask + 1} of 3</p>
          </div>

          {words[currentWordIndex] && (
            <div className="card text-center mb-8">
              <h2 className="text-2xl font-semibold text-[var(--text)] mb-2">{getTaskTitle()}</h2>
              <h3 className="text-4xl font-bold text-[var(--text)] mb-8">{words[currentWordIndex].lemma}</h3>
              {renderTask()}
            </div>
          )}
        </main>
      </div>
    );
  } catch (error) {
    console.error('DailyChallenge component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <DailyChallenge />
  </ErrorBoundary>
);