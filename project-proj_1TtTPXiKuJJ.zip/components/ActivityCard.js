function ActivityCard({ title, description, icon, route, primary = false }) {
  try {
    const handleClick = () => {
      window.location.href = route;
    };

    return (
      <div 
        className={`activity-card ${primary ? 'border-[var(--accent)]' : ''}`}
        onClick={handleClick}
        data-name="activity-card" 
        data-file="components/ActivityCard.js"
      >
        <div className="flex items-start space-x-4">
          <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
            primary ? 'bg-[var(--accent)]' : 'bg-[var(--border)]'
          }`}>
            <div className={`icon-${icon} text-xl ${
              primary ? 'text-[var(--accent-ink)]' : 'text-[var(--text)]'
            }`}></div>
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-[var(--text)] mb-1">{title}</h3>
            <p className="text-[var(--muted)] text-sm">{description}</p>
          </div>
          <div className="icon-chevron-right text-lg text-[var(--muted)]"></div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ActivityCard component error:', error);
    return null;
  }
}