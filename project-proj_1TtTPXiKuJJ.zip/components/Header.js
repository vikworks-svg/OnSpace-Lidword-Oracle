function Header() {
  try {
    return (
      <header className="border-b border-[var(--border)] bg-[var(--bg-elev)]" data-name="header" data-file="components/Header.js">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-[var(--accent)] rounded-lg flex items-center justify-center">
                <div className="icon-book text-lg text-[var(--accent-ink)]"></div>
              </div>
              <div>
                <h1 className="text-xl font-bold text-[var(--text)]">Lidwoord Oracle</h1>
                <p className="text-sm text-[var(--muted)]">Master Dutch Articles</p>
              </div>
            </div>
            
            <nav className="flex items-center space-x-6">
              <div className="hidden md:flex space-x-6">
                <a href="index.html" className="text-[var(--muted)] hover:text-[var(--accent)] transition-colors">Dashboard</a>
                <a href="quickfire.html" className="text-[var(--muted)] hover:text-[var(--accent)] transition-colors">Quickfire</a>
                <a href="ditdat.html" className="text-[var(--muted)] hover:text-[var(--accent)] transition-colors">Dit/Dat</a>
                <a href="challenge.html" className="text-[var(--muted)] hover:text-[var(--accent)] transition-colors">Challenge</a>
                <a href="lookup.html" className="text-[var(--muted)] hover:text-[var(--accent)] transition-colors">Lookup</a>
                <a href="rules.html" className="text-[var(--muted)] hover:text-[var(--accent)] transition-colors">Rules</a>
              </div>
              
              <a href="profile.html" className="flex items-center text-[var(--muted)] hover:text-[var(--accent)] transition-colors">
                <div className="icon-user text-lg mr-1"></div>
                <span className="hidden sm:inline">Profile</span>
              </a>
            </nav>
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}