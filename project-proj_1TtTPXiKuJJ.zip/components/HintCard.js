function HintCard() {
  try {
    const [hint, setHint] = React.useState('');

    React.useEffect(() => {
      const randomRule = getRandomRule();
      setHint(randomRule);
    }, []);

    const handleClick = () => {
      window.location.href = 'rules.html';
    };

    return (
      <div 
        className="card cursor-pointer hover:border-[var(--accent)] transition-colors mb-8"
        onClick={handleClick}
        data-name="hint-card" 
        data-file="components/HintCard.js"
      >
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-[var(--text)] mb-2">💡 Hint</h3>
            <p className="text-[var(--muted)]">{hint}</p>
          </div>
          <div className="icon-arrow-right text-lg text-[var(--accent)]"></div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('HintCard component error:', error);
    return null;
  }
}