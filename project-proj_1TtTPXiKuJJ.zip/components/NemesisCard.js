function NemesisCard() {
  try {
    const [nemesisWords, setNemesisWords] = React.useState([]);

    React.useEffect(() => {
      loadNemesisWords().then(setNemesisWords);
    }, []);

    const handlePractice = () => {
      window.location.href = 'quickfire.html?focus=nemesis';
    };

    if (nemesisWords.length === 0) {
      return null;
    }

    return (
      <div className="card mb-8 border-[var(--danger)]/30" data-name="nemesis-card" data-file="components/NemesisCard.js">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <div className="icon-alert-triangle text-lg text-[var(--danger)]"></div>
            <h3 className="text-lg font-semibold text-[var(--text)]">Nemesis Words</h3>
          </div>
          <button 
            onClick={handlePractice}
            className="btn btn-primary text-sm"
          >
            Practice Nemesis
          </button>
        </div>
        
        <div className="flex flex-wrap gap-2">
          {nemesisWords.slice(0, 6).map((word, index) => (
            <span 
              key={index}
              className="px-3 py-1 bg-[var(--bg)] text-[var(--danger)] border border-[var(--danger)] rounded-full text-sm"
            >
              {word.lemma}
            </span>
          ))}
          {nemesisWords.length > 6 && (
            <span className="px-3 py-1 bg-[var(--border)] text-[var(--muted)] rounded-full text-sm">
              +{nemesisWords.length - 6} more
            </span>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('NemesisCard component error:', error);
    return null;
  }
}