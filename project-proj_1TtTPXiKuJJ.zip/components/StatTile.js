function StatTile({ label, value }) {
  try {
    return (
      <div className="stat-tile" data-name="stat-tile" data-file="components/StatTile.js">
        <div className="text-2xl font-bold text-[var(--accent)] mb-1">{value}</div>
        <div className="text-sm text-[var(--muted)]">{label}</div>
      </div>
    );
  } catch (error) {
    console.error('StatTile component error:', error);
    return null;
  }
}