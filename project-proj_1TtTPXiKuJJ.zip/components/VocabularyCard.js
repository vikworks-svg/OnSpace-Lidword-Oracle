function VocabularyCard() {
  try {
    const [packs, setPacks] = React.useState([]);
    const [userStats, setUserStats] = React.useState({ streak: 0, accuracy: 0 });

    React.useEffect(() => {
      loadVocabularyPacks();
      loadUserStats();
    }, []);

    const loadVocabularyPacks = async () => {
      try {
        const packsData = await trickleListObjects('vocabulary_pack', 50);
        const sortedPacks = packsData.items
          .filter(pack => pack.objectData.is_active)
          .sort((a, b) => a.objectData.sort_order - b.objectData.sort_order);
        
        // Check unlock status for each pack
        const packsWithStatus = await Promise.all(sortedPacks.map(async (pack) => {
          const isUnlocked = await checkPackUnlocked(pack);
          return { ...pack, isUnlocked };
        }));
        
        setPacks(packsWithStatus);
      } catch (error) {
        console.error('Error loading vocabulary packs:', error);
      }
    };

    const loadUserStats = async () => {
      try {
        const attempts = await trickleListObjects('attempt', 1000);
        const correctAttempts = attempts.items.filter(a => a.objectData.correct).length;
        const accuracy = attempts.items.length > 0 ? Math.round((correctAttempts / attempts.items.length) * 100) : 0;
        
        setUserStats({ streak: 5, accuracy }); // TODO: Calculate actual streak
      } catch (error) {
        console.error('Error loading user stats:', error);
      }
    };

    const checkPackUnlocked = async (pack) => {
      const data = pack.objectData;
      
      if (data.unlock_type === 'default') return true;
      
      if (data.unlock_type === 'streak') {
        return userStats.streak >= data.unlock_value;
      }
      
      if (data.unlock_type === 'accuracy') {
        return userStats.accuracy >= data.unlock_value;
      }
      
      if (data.unlock_type === 'previous_pack') {
        // Check if previous pack has required accuracy
        const progress = await trickleListObjects('pack_progress', 100);
        // TODO: Implement previous pack check
        return false;
      }
      
      return false;
    };

    const handlePackClick = (pack) => {
      if (!pack.isUnlocked) return;
      window.location.href = `vocabulary.html?pack=${pack.objectId}`;
    };

    return (
      <div className="card mb-8" data-name="vocabulary-card" data-file="components/VocabularyCard.js">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <div className="icon-book-open text-lg text-[var(--accent)]"></div>
            <h3 className="text-lg font-semibold text-[var(--text)]">Vocabulary Packs</h3>
          </div>
          <button 
            onClick={() => window.location.href = 'vocabulary.html'}
            className="text-sm text-[var(--accent)] hover:underline"
          >
            View All
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {packs.slice(0, 6).map((pack, index) => (
            <div
              key={index}
              onClick={() => handlePackClick(pack)}
              className={`p-4 rounded-lg border transition-colors ${
                pack.isUnlocked
                  ? 'border-[var(--border)] hover:border-[var(--accent)] cursor-pointer bg-[var(--bg)]'
                  : 'border-[var(--border)] bg-[var(--bg)] opacity-60'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <h4 className="font-medium text-[var(--text)] text-sm">{pack.objectData.name}</h4>
                {pack.isUnlocked ? (
                  <div className="icon-unlock text-sm text-[var(--accent)]"></div>
                ) : (
                  <div className="icon-lock text-sm text-[var(--muted)]"></div>
                )}
              </div>
              
              <p className="text-xs text-[var(--muted)] mb-2">{pack.objectData.description}</p>
              
              <div className="flex items-center justify-between">
                <span className="text-xs text-[var(--muted)]">{pack.objectData.word_count} words</span>
                {!pack.isUnlocked && (
                  <span className="text-xs text-[var(--muted)]">{pack.objectData.unlock_requirement}</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  } catch (error) {
    console.error('VocabularyCard component error:', error);
    return null;
  }
}