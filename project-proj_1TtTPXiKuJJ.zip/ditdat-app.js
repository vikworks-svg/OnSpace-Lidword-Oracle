class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--bg)]">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-[var(--text)] mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function DitDatDash() {
  try {
    const [gameState, setGameState] = React.useState('menu'); // menu, playing, results
    const [difficulty, setDifficulty] = React.useState('medium');
    const [currentWord, setCurrentWord] = React.useState(null);
    const [proximity, setProximity] = React.useState('NEAR');
    const [score, setScore] = React.useState(0);
    const [timeLeft, setTimeLeft] = React.useState(60);
    const [feedback, setFeedback] = React.useState(null);
    const [gameWords, setGameWords] = React.useState([]);
    const [wordIndex, setWordIndex] = React.useState(0);

    React.useEffect(() => {
      let interval;
      if (gameState === 'playing' && timeLeft > 0 && !feedback) {
        interval = setInterval(() => {
          setTimeLeft(prev => prev - 1);
        }, 1000);
      } else if (timeLeft === 0) {
        setGameState('results');
      }
      return () => clearInterval(interval);
    }, [gameState, timeLeft, feedback]);

    const startGame = async () => {
      try {
        const words = await getWeightedWords(20);
        setGameWords(words);
        setCurrentWord(words[0]);
        setProximity(Math.random() > 0.5 ? 'NEAR' : 'FAR');
        setGameState('playing');
        setScore(0);
        setTimeLeft(60);
        setWordIndex(0);
      } catch (error) {
        console.error('Error starting game:', error);
      }
    };

    const handleAnswer = async (answer) => {
      if (!currentWord || feedback) return;

      const correct = getCorrectDemonstrative(currentWord.article, proximity);
      const isCorrect = answer === correct;

      if (isCorrect) {
        setScore(prev => prev + 1);
      }

      const feedbackText = getRandomFeedback(isCorrect);
      setFeedback({ text: feedbackText, correct: isCorrect });

      await recordAttempt(currentWord.id, 'ditdat', isCorrect, answer);

      // Auto dismiss feedback after 1800ms
      setTimeout(() => {
        continueGame();
      }, 1800);
    };

    const continueGame = () => {
      setFeedback(null);
      
      if (wordIndex + 1 < gameWords.length) {
        const nextIndex = wordIndex + 1;
        setWordIndex(nextIndex);
        setCurrentWord(gameWords[nextIndex]);
        setProximity(Math.random() > 0.5 ? 'NEAR' : 'FAR');
      } else {
        // Load more words
        startGame();
      }
    };

    const getDifficultyOptions = () => {
      if (!currentWord) return [];

      const correct = getCorrectDemonstrative(currentWord.article, proximity);
      
      if (difficulty === 'easy') {
        const sameArticle = currentWord.article === 'het' ? ['dit', 'dat'] : ['deze', 'die'];
        return [correct, sameArticle.find(opt => opt !== correct)];
      } else {
        return ['dit', 'dat', 'deze', 'die'];
      }
    };

    if (gameState === 'menu') {
      return (
        <div className="min-h-screen bg-[var(--bg)]">
          <Header />
          <main className="max-w-2xl mx-auto px-4 py-8">
            <div className="card text-center">
              <div className="w-16 h-16 bg-[var(--accent)] rounded-lg mx-auto mb-6 flex items-center justify-center">
                <div className="icon-zap text-2xl text-[var(--accent-ink)]"></div>
              </div>
              
              <h1 className="text-3xl font-bold text-[var(--text)] mb-4">Dit/Dat Dash</h1>
              <p className="text-[var(--muted)] mb-8">Choose the correct demonstrative for each word</p>

              <div className="mb-6">
                <h3 className="text-lg font-semibold text-[var(--text)] mb-3">Difficulty</h3>
                <div className="flex gap-2 justify-center">
                  {[
                    { value: 'easy', label: 'Easy', desc: '2 options' },
                    { value: 'medium', label: 'Medium', desc: '4 options' },
                    { value: 'hard', label: 'Hard', desc: 'No article shown' }
                  ].map(diff => (
                    <button
                      key={diff.value}
                      onClick={() => setDifficulty(diff.value)}
                      className={`btn ${difficulty === diff.value ? 'btn-primary' : 'btn-secondary'} text-sm`}
                    >
                      {diff.label}
                    </button>
                  ))}
                </div>
              </div>

              <button onClick={startGame} className="btn btn-primary text-lg px-8 py-3">
                Start Game
              </button>
            </div>
          </main>
        </div>
      );
    }

    if (gameState === 'results') {
      return (
        <div className="min-h-screen bg-[var(--bg)]">
          <Header />
          <main className="max-w-2xl mx-auto px-4 py-8">
            <div className="card text-center">
              <div className="w-16 h-16 bg-[var(--accent)] rounded-lg mx-auto mb-6 flex items-center justify-center">
                <div className="icon-trophy text-2xl text-[var(--accent-ink)]"></div>
              </div>
              
              <h1 className="text-3xl font-bold text-[var(--text)] mb-4">Game Complete!</h1>
              <div className="text-4xl font-bold text-[var(--accent)] mb-2">{score}</div>
              <p className="text-[var(--muted)] mb-8">Correct answers</p>

              <div className="flex gap-4 justify-center">
                <button onClick={() => setGameState('menu')} className="btn btn-secondary">
                  Menu
                </button>
                <button onClick={startGame} className="btn btn-primary">
                  Play Again
                </button>
              </div>
            </div>
          </main>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-[var(--bg)]">
        <Header />
        
        {feedback && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="card max-w-md w-full mx-4 text-center">
              <h2 className={`text-2xl font-bold mb-4 ${feedback.correct ? 'text-[var(--accent)]' : 'text-[var(--danger)]'}`}>
                {feedback.text}
              </h2>
              <button onClick={continueGame} className="btn btn-primary">
                Continue
              </button>
            </div>
          </div>
        )}

        <main className="max-w-2xl mx-auto px-4 py-8">
          {/* Game Header */}
          <div className="flex justify-between items-center mb-8">
            <div className="text-2xl font-bold text-[var(--accent)]">Score: {score}</div>
            <div className="text-2xl font-bold text-[var(--text)]">:{timeLeft.toString().padStart(2, '0')}</div>
          </div>

          {/* Game Card */}
          {currentWord && (
            <div className="card text-center mb-8">
              <div className="mb-6">
                <div className={`inline-block px-4 py-2 rounded-full text-sm font-medium mb-4 ${
                  proximity === 'NEAR' ? 'bg-[var(--bg)] text-[var(--accent)] border border-[var(--accent)]' : 'bg-[var(--bg)] text-[var(--muted)] border border-[var(--muted)]'
                }`}>
                  {proximity}
                </div>
                
                {difficulty !== 'hard' && (
                  <div className={`inline-block px-3 py-1 rounded-full text-xs font-medium mb-4 ml-2 ${
                    currentWord.article === 'de' ? 'bg-blue-500/20 text-blue-400' : 'bg-purple-500/20 text-purple-400'
                  }`}>
                    {currentWord.article}
                  </div>
                )}
              </div>

              <h2 className="text-3xl font-bold text-[var(--text)] mb-8">{currentWord.lemma}</h2>
              
              <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
                {getDifficultyOptions().map(option => (
                  <button
                    key={option}
                    onClick={() => handleAnswer(option)}
                    className="btn btn-secondary text-xl py-4"
                    disabled={!!feedback}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
    );
  } catch (error) {
    console.error('DitDatDash component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <DitDatDash />
  </ErrorBoundary>
);