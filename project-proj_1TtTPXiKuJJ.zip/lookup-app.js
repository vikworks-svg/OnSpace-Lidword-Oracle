class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--bg)]">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-[var(--text)] mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function Lookup() {
  try {
    const [searchTerm, setSearchTerm] = React.useState('');
    const [searchResults, setSearchResults] = React.useState([]);
    const [isLoading, setIsLoading] = React.useState(false);

    const searchWords = async (term) => {
      if (!term.trim()) {
        setSearchResults([]);
        return;
      }

      setIsLoading(true);
      try {
        const words = await trickleListObjects('word', 100);
        const filtered = words.items.filter(word => 
          word.objectData.lemma.toLowerCase().includes(term.toLowerCase()) ||
          word.objectData.gloss_en.toLowerCase().includes(term.toLowerCase())
        );
        setSearchResults(filtered);
      } catch (error) {
        console.error('Error searching words:', error);
        setSearchResults([]);
      }
      setIsLoading(false);
    };

    React.useEffect(() => {
      const debounceTimer = setTimeout(() => {
        searchWords(searchTerm);
      }, 300);

      return () => clearTimeout(debounceTimer);
    }, [searchTerm]);

    const getDerivedChips = (article) => {
      if (article === 'de') {
        return ['deze', 'die', 'onze'];
      } else {
        return ['dit', 'dat', 'ons'];
      }
    };

    return (
      <div className="min-h-screen bg-[var(--bg)]">
        <Header />
        
        <main className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-[var(--text)] mb-4">Word Lookup</h1>
            <p className="text-[var(--muted)]">Search for Dutch words and their articles</p>
          </div>

          {/* Search Bar */}
          <div className="card mb-8">
            <div className="relative">
              <div className="icon-search text-lg text-[var(--muted)] absolute left-3 top-1/2 transform -translate-y-1/2"></div>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search words..."
                className="w-full pl-10 pr-4 py-3 bg-[var(--bg)] border border-[var(--border)] rounded-lg text-[var(--text)] focus:border-[var(--accent)] focus:outline-none"
              />
            </div>
          </div>

          {/* Results */}
          {isLoading ? (
            <div className="text-center py-8">
              <div className="icon-loader text-2xl text-[var(--accent)] mb-4"></div>
              <p className="text-[var(--muted)]">Searching...</p>
            </div>
          ) : searchResults.length > 0 ? (
            <div className="space-y-4">
              {searchResults.map((word, index) => (
                <div key={index} className="card">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-2xl font-bold text-[var(--text)]">{word.objectData.lemma}</h3>
                      <p className="text-[var(--muted)]">{word.objectData.gloss_en}</p>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                      word.objectData.article === 'de' ? 'bg-blue-500/20 text-blue-400' : 'bg-purple-500/20 text-purple-400'
                    }`}>
                      {word.objectData.article}
                    </div>
                  </div>

                  {/* Derived chips */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {getDerivedChips(word.objectData.article).map(chip => (
                      <span key={chip} className="px-3 py-1 bg-[var(--border)] text-[var(--text)] rounded-full text-sm">
                        {chip}
                      </span>
                    ))}
                  </div>

                  {/* Grammar note */}
                  {word.objectData.note && (
                    <div className="bg-[var(--bg)] rounded-lg p-3 border-l-4 border-[var(--accent)]">
                      <p className="text-sm text-[var(--muted)]">{word.objectData.note}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : searchTerm && !isLoading ? (
            <div className="text-center py-8">
              <div className="icon-search text-2xl text-[var(--muted)] mb-4"></div>
              <p className="text-[var(--muted)] mb-4">No words found for "{searchTerm}"</p>
              <button className="btn btn-primary">
                Add Word
              </button>
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="icon-search text-2xl text-[var(--muted)] mb-4"></div>
              <p className="text-[var(--muted)]">Start typing to search for words</p>
            </div>
          )}
        </main>
      </div>
    );
  } catch (error) {
    console.error('Lookup component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <Lookup />
  </ErrorBoundary>
);