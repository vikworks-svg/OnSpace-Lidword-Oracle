class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--bg)]">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-[var(--text)] mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function Profile() {
  try {
    const [user, setUser] = React.useState({
      name: 'Demo User',
      email: 'demo@example.com',
      joinDate: '2024-10-01',
      level: 'Intermediate'
    });
    const [stats, setStats] = React.useState({
      totalGames: 0,
      accuracy: 0,
      streak: 0,
      masteredWords: 0
    });
    const [editMode, setEditMode] = React.useState(false);
    const [formData, setFormData] = React.useState(user);

    React.useEffect(() => {
      loadUserStats();
    }, []);

    const loadUserStats = async () => {
      try {
        const attempts = await trickleListObjects('attempt', 1000);
        const progress = await trickleListObjects('progress', 100);
        
        const totalGames = attempts.items.length;
        const correctAttempts = attempts.items.filter(a => a.objectData.correct).length;
        const accuracy = totalGames > 0 ? Math.round((correctAttempts / totalGames) * 100) : 0;
        const masteredWords = progress.items.filter(p => p.objectData.isMastered).length;

        setStats({
          totalGames,
          accuracy,
          streak: 5, // TODO: Calculate actual streak
          masteredWords
        });
      } catch (error) {
        console.error('Error loading user stats:', error);
      }
    };

    const handleSave = () => {
      setUser(formData);
      setEditMode(false);
    };

    const handleLogout = () => {
      // Clear any stored auth data
      localStorage.removeItem('user');
      window.location.href = 'login.html';
    };

    return (
      <div className="min-h-screen bg-[var(--bg)]">
        <Header />
        
        <main className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-[var(--text)] mb-2">Profile</h1>
            <p className="text-[var(--muted)]">Manage your account and view your progress</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* User Info */}
            <div className="card">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-[var(--text)]">Account Information</h2>
                <button
                  onClick={() => setEditMode(!editMode)}
                  className="btn btn-secondary text-sm"
                >
                  <div className="icon-edit text-sm mr-1"></div>
                  {editMode ? 'Cancel' : 'Edit'}
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-[var(--muted)] mb-2">Name</label>
                  {editMode ? (
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="input"
                    />
                  ) : (
                    <p className="text-[var(--text)]">{user.name}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--muted)] mb-2">Email</label>
                  {editMode ? (
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="input"
                    />
                  ) : (
                    <p className="text-[var(--text)]">{user.email}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--muted)] mb-2">Level</label>
                  <p className="text-[var(--text)]">{user.level}</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--muted)] mb-2">Member Since</label>
                  <p className="text-[var(--text)]">{new Date(user.joinDate).toLocaleDateString()}</p>
                </div>

                {editMode && (
                  <button onClick={handleSave} className="btn btn-primary w-full">
                    Save Changes
                  </button>
                )}
              </div>
            </div>

            {/* Statistics */}
            <div className="card">
              <h2 className="text-xl font-semibold text-[var(--text)] mb-6">Your Statistics</h2>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-[var(--bg)] rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-[var(--accent)] mb-1">{stats.totalGames}</div>
                  <div className="text-sm text-[var(--muted)]">Games Played</div>
                </div>
                
                <div className="bg-[var(--bg)] rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-[var(--accent)] mb-1">{stats.accuracy}%</div>
                  <div className="text-sm text-[var(--muted)]">Accuracy</div>
                </div>
                
                <div className="bg-[var(--bg)] rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-[var(--accent)] mb-1">{stats.streak}</div>
                  <div className="text-sm text-[var(--muted)]">Day Streak</div>
                </div>
                
                <div className="bg-[var(--bg)] rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-[var(--accent)] mb-1">{stats.masteredWords}</div>
                  <div className="text-sm text-[var(--muted)]">Mastered</div>
                </div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-center mt-8 space-x-4">
            <button
              onClick={() => window.location.href = 'index.html'}
              className="btn btn-secondary"
            >
              <div className="icon-arrow-left text-lg mr-2"></div>
              Back to Dashboard
            </button>
            
            <button
              onClick={handleLogout}
              className="btn text-[var(--danger)] hover:bg-[var(--danger)]/10 border-[var(--danger)]"
            >
              <div className="icon-log-out text-lg mr-2"></div>
              Sign Out
            </button>
          </div>
        </main>
      </div>
    );
  } catch (error) {
    console.error('Profile component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <Profile />
  </ErrorBoundary>
);