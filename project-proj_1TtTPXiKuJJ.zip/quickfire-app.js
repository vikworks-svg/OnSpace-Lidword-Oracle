class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--bg)]">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-[var(--text)] mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function Quickfire() {
  try {
    const [gameState, setGameState] = React.useState('menu');
    const [currentWord, setCurrentWord] = React.useState(null);
    const [score, setScore] = React.useState(0);
    const [timeLeft, setTimeLeft] = React.useState(60);
    const [feedback, setFeedback] = React.useState(null);
    const [gameWords, setGameWords] = React.useState([]);
    const [wordIndex, setWordIndex] = React.useState(0);

    React.useEffect(() => {
      let interval;
      if (gameState === 'playing' && timeLeft > 0 && !feedback) {
        interval = setInterval(() => {
          setTimeLeft(prev => prev - 1);
        }, 1000);
      } else if (timeLeft === 0) {
        setGameState('results');
      }
      return () => clearInterval(interval);
    }, [gameState, timeLeft, feedback]);



    const startGame = async () => {
      try {
        const urlParams = new URLSearchParams(window.location.search);
        const focus = urlParams.get('focus');
        
        let words;
        if (focus === 'nemesis') {
          const nemesisWords = await loadNemesisWords();
          words = nemesisWords.length > 0 ? nemesisWords : await getWeightedWords(30);
        } else {
          words = await getWeightedWords(30);
        }
        
        setGameWords(words);
        setCurrentWord(words[0]);
        setGameState('playing');
        setScore(0);
        setTimeLeft(60);
        setWordIndex(0);
      } catch (error) {
        console.error('Error starting game:', error);
      }
    };

    const handleAnswer = async (answer) => {
      if (!currentWord || feedback) return;

      const isCorrect = answer === currentWord.article;
      
      if (isCorrect) {
        setScore(prev => prev + 1);
      }

      const feedbackText = getRandomFeedback(isCorrect);
      setFeedback({ text: feedbackText, correct: isCorrect });

      await recordAttempt(currentWord.id, 'quickfire', isCorrect, answer);

      setTimeout(() => {
        continueGame();
      }, 1800);
    };

    const continueGame = () => {
      setFeedback(null);
      
      if (wordIndex + 1 < gameWords.length) {
        const nextIndex = wordIndex + 1;
        setWordIndex(nextIndex);
        setCurrentWord(gameWords[nextIndex]);
      } else {
        startGame();
      }
    };

    if (gameState === 'menu') {
      return (
        <div className="min-h-screen bg-[var(--bg)]">
          <Header />
          <main className="max-w-2xl mx-auto px-4 py-8">
            <div className="card text-center">
              <div className="w-16 h-16 bg-[var(--accent)] rounded-lg mx-auto mb-6 flex items-center justify-center">
                <div className="icon-timer text-2xl text-[var(--accent-ink)]"></div>
              </div>
              
              <h1 className="text-3xl font-bold text-[var(--text)] mb-4">De/Het Quickfire</h1>
              <p className="text-[var(--muted)] mb-8">Choose the correct article in 60 seconds</p>

              <button onClick={startGame} className="btn btn-primary text-lg px-8 py-3">
                Start Game
              </button>
            </div>
          </main>
        </div>
      );
    }

    if (gameState === 'results') {
      return (
        <div className="min-h-screen bg-[var(--bg)]">
          <Header />
          <main className="max-w-2xl mx-auto px-4 py-8">
            <div className="card text-center">
              <div className="w-16 h-16 bg-[var(--accent)] rounded-lg mx-auto mb-6 flex items-center justify-center">
                <div className="icon-trophy text-2xl text-[var(--accent-ink)]"></div>
              </div>
              
              <h1 className="text-3xl font-bold text-[var(--text)] mb-4">Time's Up!</h1>
              <div className="text-4xl font-bold text-[var(--accent)] mb-2">{score}</div>
              <p className="text-[var(--muted)] mb-8">Correct answers</p>

              <div className="flex gap-4 justify-center">
                <button onClick={() => setGameState('menu')} className="btn btn-secondary">
                  Menu
                </button>
                <button onClick={startGame} className="btn btn-primary">
                  Play Again
                </button>
              </div>
            </div>
          </main>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-[var(--bg)]">
        <Header />
        
        {feedback && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="card max-w-md w-full mx-4 text-center">
              <h2 className={`text-2xl font-bold mb-4 ${feedback.correct ? 'text-[var(--accent)]' : 'text-[var(--danger)]'}`}>
                {feedback.text}
              </h2>
              <button onClick={continueGame} className="btn btn-primary">
                Continue
              </button>
            </div>
          </div>
        )}

        <main className="max-w-2xl mx-auto px-4 py-8">
          <div className="flex justify-between items-center mb-8">
            <div className="text-2xl font-bold text-[var(--accent)]">Score: {score}</div>
            <div className="text-2xl font-bold text-[var(--text)]">0:{timeLeft.toString().padStart(2, '0')}</div>
          </div>

          {currentWord && (
            <div className="card text-center mb-8">
              <h2 className="text-4xl font-bold text-[var(--text)] mb-8">{currentWord.lemma}</h2>
              
              <div className="grid grid-cols-2 gap-6 max-w-md mx-auto">
                <button
                  onClick={() => handleAnswer('de')}
                  className="btn btn-secondary text-2xl py-6"
                  disabled={!!feedback}
                >
                  de
                </button>
                <button
                  onClick={() => handleAnswer('het')}
                  className="btn btn-secondary text-2xl py-6"
                  disabled={!!feedback}
                >
                  het
                </button>
              </div>
            </div>
          )}
        </main>
      </div>
    );
  } catch (error) {
    console.error('Quickfire component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <Quickfire />
  </ErrorBoundary>
);
