class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--bg)]">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-[var(--text)] mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function Rules() {
  try {
    const rules = [
      {
        title: "Diminutives",
        content: "Diminutives end in -je and always take 'het'",
        examples: ["het meisje (girl)", "het kopje (little cup)", "het huisje (little house)"]
      },
      {
        title: "Abstract Endings",
        content: "Words ending in -heid, -ing, -te, -nis take 'de'",
        examples: ["de vrijheid (freedom)", "de vergadering (meeting)", "de kennis (knowledge)"]
      },
      {
        title: "Borrowed Endings", 
        content: "Endings like -isme, -ment, -um often take 'het'",
        examples: ["het communisme", "het document", "het museum"]
      },
      {
        title: "Compounds",
        content: "In compounds, the last word determines the article",
        examples: ["e-mailadres → adres → het", "waterkoker → koker → de"]
      },
      {
        title: "Languages & Metals",
        content: "Languages and metals take 'het'",
        examples: ["het Engels", "het goud", "het zilver"]
      },
      {
        title: "Demonstratives: Sound Pattern",
        content: "Remember: de → deze/die (E sound), het → dit/dat (T sound)",
        examples: ["de tafel → deze tafel", "het huis → dit huis"]
      },
      {
        title: "Adjectives with de-words",
        content: "For adjectives with de-words: add -e",
        examples: ["de rode tafel", "de kleine auto", "de mooie bloem"]
      },
      {
        title: "Adjectives with het-words (no article)",
        content: "For adjectives with het-words (no article/indefinite): no -e",
        examples: ["een klein huis", "mooi weer", "goed eten"]
      },
      {
        title: "Adjectives with het/demonstratives/plurals",
        content: "With het/demonstratives/plurals: add -e",
        examples: ["het kleine huis", "dat kleine huis", "twee kleine huizen"]
      }
    ];

    return (
      <div className="min-h-screen bg-[var(--bg)]">
        <Header />
        
        <main className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-[var(--text)] mb-4">Grammar Rules</h1>
            <p className="text-[var(--muted)]">Master Dutch articles and adjectives</p>
          </div>

          <div className="space-y-6">
            {rules.map((rule, index) => (
              <div key={index} className="rule-card">
                <h3 className="text-xl font-semibold text-[var(--text)] mb-3">{rule.title}</h3>
                <p className="text-[var(--muted)] mb-4">{rule.content}</p>
                
                <div className="bg-[var(--bg)] rounded-lg p-4">
                  <h4 className="text-sm font-medium text-[var(--accent)] mb-2">Examples:</h4>
                  <div className="flex flex-wrap gap-2">
                    {rule.examples.map((example, exIndex) => (
                      <span 
                        key={exIndex}
                        className="px-3 py-1 bg-[var(--border)] text-[var(--text)] rounded-full text-sm"
                      >
                        {example}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <div className="card">
              <h3 className="text-xl font-semibold text-[var(--text)] mb-4">Practice Makes Perfect</h3>
              <p className="text-[var(--muted)] mb-6">Ready to put these rules into practice?</p>
              <div className="flex gap-4 justify-center">
                <button 
                  onClick={() => window.location.href = 'quickfire.html'}
                  className="btn btn-primary"
                >
                  Start Quickfire
                </button>
                <button 
                  onClick={() => window.location.href = 'ditdat.html'}
                  className="btn btn-secondary"
                >
                  Try Dit/Dat
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  } catch (error) {
    console.error('Rules component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <Rules />
  </ErrorBoundary>
);
