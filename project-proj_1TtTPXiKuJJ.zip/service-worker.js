const CACHE_NAME = 'lidwoord-oracle-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/ditdat.html',
  '/quickfire.html',
  '/challenge.html',
  '/lookup.html',
  '/rules.html',
  '/app.js',
  '/ditdat-app.js',
  '/quickfire-app.js',
  '/challenge-app.js',
  '/lookup-app.js',
  '/rules-app.js',
  '/components/Header.js',
  '/components/StatTile.js',
  '/components/ActivityCard.js',
  '/components/HintCard.js',
  '/components/NemesisCard.js',
  '/utils/seedWords.js',
  '/utils/storage.js',
  '/utils/gameLogic.js',
  '/utils/rules.js',
  '/utils/feedback.js',
  '/manifest.json',
  'https://resource.trickle.so/vendor_lib/unpkg/react@18/umd/react.production.min.js',
  'https://resource.trickle.so/vendor_lib/unpkg/react-dom@18/umd/react-dom.production.min.js',
  'https://resource.trickle.so/vendor_lib/unpkg/@babel/standalone/babel.min.js',
  'https://cdn.tailwindcss.com',
  'https://resource.trickle.so/vendor_lib/unpkg/lucide-static@0.516.0/font/lucide.css'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        if (response) {
          return response;
        }
        return fetch(event.request);
      }
    )
  );
});