lemma	article	near_demo	far_demo	possessive	translation
koekje	het	dit	dat	ons	cookie
brood	het	dit	dat	ons	bread
boterham	de	deze	die	onze	sandwich (slice of bread)
kaas	de	deze	die	onze	cheese
melk	de	deze	die	onze	milk
suiker	de	deze	die	onze	sugar
zout	het	dit	dat	ons	salt
peper	de	deze	die	onze	pepper
ei	het	dit	dat	ons	egg
soep	de	deze	die	onze	soup
salade	de	deze	die	onze	salad
groente	de	deze	die	onze	vegetable(s)
fruit	het	dit	dat	ons	fruit
appel	de	deze	die	onze	apple
banaan	de	deze	die	onze	banana
sinaasappel	de	deze	die	onze	orange
aardbei	de	deze	die	onze	strawberry
druif	de	deze	die	onze	grape
tomaat	de	deze	die	onze	tomato
komkommer	de	deze	die	onze	cucumber
ui	de	deze	die	onze	onion
knoflook	de	deze	die	onze	garlic
wortel	de	deze	die	onze	carrot
aardappel	de	deze	die	onze	potato
rijst	de	deze	die	onze	rice
pasta	de	deze	die	onze	pasta
saus	de	deze	die	onze	sauce
olie	de	deze	die	onze	oil
boter	de	deze	die	onze	butter
bloem	de	deze	die	onze	flour
fornuis	het	dit	dat	ons	stove
aanrecht	het	dit	dat	ons	countertop
gootsteen	de	deze	die	onze	kitchen sink
vaatwasser	de	deze	die	onze	dishwasher
bestek	het	dit	dat	ons	cutlery
servet	het	dit	dat	ons	napkin
tafelkleed	het	dit	dat	ons	tablecloth
schaal	de	deze	die	onze	serving dish
beker	de	deze	die	onze	cup (beaker)
mok	de	deze	die	onze	mug
flesopener	de	deze	die	onze	bottle opener
kurkentrekker	de	deze	die	onze	corkscrew
plant	de	deze	die	onze	plant
vaas	de	deze	die	onze	vase
gordijn	het	dit	dat	ons	curtain
kussen	het	dit	dat	ons	pillow
dekbed	het	dit	dat	ons	duvet
deken	de	deze	die	onze	blanket
laken	het	dit	dat	ons	sheet
matras	het	dit	dat	ons	mattress
stopcontact	het	dit	dat	ons	power outlet
stekker	de	deze	die	onze	plug
kabel	de	deze	die	onze	cable
oplader	de	deze	die	onze	charger
afstandsbediening	de	deze	die	onze	remote control
televisie	de	deze	die	onze	television
radio	de	deze	die	onze	radio
luidspreker	de	deze	die	onze	loudspeaker
stofzuiger	de	deze	die	onze	vacuum cleaner
bezem	de	deze	die	onze	broom
dweil	de	deze	die	onze	mop
emmer	de	deze	die	onze	bucket
zeep	de	deze	die	onze	soap
shampoo	de	deze	die	onze	shampoo
tandpasta	de	deze	die	onze	toothpaste
tandenborstel	de	deze	die	onze	toothbrush
handdoek	de	deze	die	onze	towel
spiegel	de	deze	die	onze	mirror
jas	de	deze	die	onze	coat
trui	de	deze	die	onze	sweater
T-shirt	het	dit	dat	ons	T-shirt
overhemd	het	dit	dat	ons	dress shirt
blouse	de	deze	die	onze	blouse
broek	de	deze	die	onze	trousers
rok	de	deze	die	onze	skirt
jurk	de	deze	die	onze	dress
sok	de	deze	die	onze	sock
schoen	de	deze	die	onze	shoe
laars	de	deze	die	onze	boot
pet	de	deze	die	onze	cap
hoed	de	deze	die	onze	hat
riem	de	deze	die	onze	belt
handschoen	de	deze	die	onze	glove
sjaal	de	deze	die	onze	scarf
bril	de	deze	die	onze	glasses
zonnebril	de	deze	die	onze	sunglasses
horloge	het	dit	dat	ons	watch
ketting	de	deze	die	onze	necklace
oorbel	de	deze	die	onze	earring
hoofd	het	dit	dat	ons	head
gezicht	het	dit	dat	ons	face
haar	het	dit	dat	ons	hair
oog	het	dit	dat	ons	eye
oor	het	dit	dat	ons	ear
neus	de	deze	die	onze	nose
mond	de	deze	die	onze	mouth
tand	de	deze	die	onze	tooth
tong	de	deze	die	onze	tongue
keel	de	deze	die	onze	throat
schouder	de	deze	die	onze	shoulder
arm	de	deze	die	onze	arm
hand	de	deze	die	onze	hand
vinger	de	deze	die	onze	finger
borst	de	deze	die	onze	chest
rug	de	deze	die	onze	back
buik	de	deze	die	onze	belly
been	het	dit	dat	ons	leg
knie	de	deze	die	onze	knee
voet	de	deze	die	onze	foot
teen	de	deze	die	onze	toe
huid	de	deze	die	onze	skin
spier	de	deze	die	onze	muscle
bloed	het	dit	dat	ons	blood
hart	het	dit	dat	ons	heart
zee	de	deze	die	onze	sea
rivier	de	deze	die	onze	river
meer	het	dit	dat	ons	lake
strand	het	dit	dat	ons	beach
bos	het	dit	dat	ons	forest
boom	de	deze	die	onze	tree
tak	de	deze	die	onze	branch
blad	het	dit	dat	ons	leaf
gras	het	dit	dat	ons	grass
steen	de	deze	die	onze	stone
berg	de	deze	die	onze	mountain
heuvel	de	deze	die	onze	hill
wolk	de	deze	die	onze	cloud
regen	de	deze	die	onze	rain
sneeuw	de	deze	die	onze	snow
wind	de	deze	die	onze	wind
zon	de	deze	die	onze	sun
maan	de	deze	die	onze	moon
ster	de	deze	die	onze	star
temperatuur	de	deze	die	onze	temperature
weer	het	dit	dat	ons	weather
restaurant	het	dit	dat	ons	restaurant
café	het	dit	dat	ons	café
winkel	de	deze	die	onze	shop
supermarkt	de	deze	die	onze	supermarket
bakker	de	deze	die	onze	baker/bakery
slager	de	deze	die	onze	butcher
apotheek	de	deze	die	onze	pharmacy
tram	de	deze	die	onze	tram
metro	de	deze	die	onze	subway/metro
taxi	de	deze	die	onze	taxi
motor	de	deze	die	onze	motorcycle
scooter	de	deze	die	onze	scooter
helm	de	deze	die	onze	helmet
benzine	de	deze	die	onze	gasoline
parkeerplaats	de	deze	die	onze	parking space
bibliotheek	de	deze	die	onze	library
boekwinkel	de	deze	die	onze	bookshop
kantoor	het	dit	dat	ons	office
vergunning	de	deze	die	onze	permit
rekening	de	deze	die	onze	bill/account statement
bon	de	deze	die	onze	receipt
pinautomaat	de	deze	die	onze	ATM
portemonnee	de	deze	die	onze	wallet
sleutel	de	deze	die	onze	key
sleutelbos	de	deze	die	onze	keyring
rugzak	de	deze	die	onze	backpack
tas	de	deze	die	onze	bag
koffer	de	deze	die	onze	suitcase
paspoort	het	dit	dat	ons	passport
identiteitskaart	de	deze	die	onze	ID card
verzekering	de	deze	die	onze	insurance
dokter	de	deze	die	onze	doctor
tandarts	de	deze	die	onze	dentist
afspraakkaartje	het	dit	dat	ons	appointment card
ziekenhuis	het	dit	dat	ons	hospital
aparte kamer	de	deze	die	onze	private room
receptie	de	deze	die	onze	reception
wachtruimte	de	deze	die	onze	waiting room
thermostaat	de	deze	die	onze	thermostat
verwarming	de	deze	die	onze	heating
airco	de	deze	die	onze	air conditioner
raamdecoratie	de	deze	die	onze	window covering
trap	de	deze	die	onze	stairs
lift	de	deze	die	onze	elevator
balkon	het	dit	dat	ons	balcony
zolder	de	deze	die	onze	attic
kelder	de	deze	die	onze	basement
schuur	de	deze	die	onze	shed
garage	de	deze	die	onze	garage
tuin	de	deze	die	onze	garden
grasmaaier	de	deze	die	onze	lawn mower
gieter	de	deze	die	onze	watering can
barbecue	de	deze	die	onze	barbecue (grill)
vuilnisbak	de	deze	die	onze	trash bin
recycling	het	dit	dat	ons	recycling
pakket	het	dit	dat	ons	package
bezorger	de	deze	die	onze	delivery person
postbode	de	deze	die	onze	mail carrier
brievenbus	de	deze	die	onze	mailbox (slot)
stoplicht	het	dit	dat	ons	traffic light
rotonde	de	deze	die	onze	roundabout
kruispunt	het	dit	dat	ons	intersection
zebra	het	dit	dat	ons	crosswalk
boete	de	deze	die	onze	fine (penalty)
politie	de	deze	die	onze	police
brandweer	de	deze	die	onze	fire brigade
ambulance	de	deze	die	onze	ambulance
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
