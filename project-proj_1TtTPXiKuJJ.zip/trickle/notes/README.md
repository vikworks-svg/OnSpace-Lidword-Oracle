# Lidwoord Oracle - Dutch Article Practice PWA

## Project Overview
A progressive web app for mastering Dutch articles (de/het) and demonstratives (dit/dat/deze/die) through interactive games and practice exercises.

## Features
- **Dit/Dat Dash**: Primary game for demonstrative practice with difficulty levels
- **De/Het Quickfire**: 60-second article practice with keyboard support
- **Daily Challenge**: 3 words × 3 tasks (article, demonstrative, adjective)
- **Lookup**: Dictionary search for Dutch words and grammar notes
- **Rules**: Comprehensive grammar explanations
- **Nemesis System**: Tracks problematic words for focused practice
- **Mastery Tracking**: Progress system with streaks and accuracy

## Technical Stack
- React 18 with Babel for components
- TailwindCSS for styling with dark theme
- Trickle Database for data persistence
- PWA with service worker for offline support
- Local storage fallback for offline functionality

## Design System
Premium dark theme with mint-cyan accent (#00E5C4):
- Background: #0E0F12
- Elevated: #14161B  
- Text: #F4F6F8
- Muted: #9AA3AF
- Border: #23262F
- Accent: #00E5C4

## Data Structure
- **Words**: lemma, article, note, gloss_en
- **Attempts**: tracks all user interactions
- **Progress**: mastery and nemesis status per word
- **Daily Challenge**: manages daily word selection

## Game Mechanics
- **Nemesis**: wrong ≥ right AND ≥2 wrong (2-3x weight)
- **Mastered**: 3+ correct streak (excluded from rotation)
- **Feedback**: Auto-dismiss after 1800ms, headline-only
- **Timer**: Pauses during feedback display

Created: October 2, 2025