lemma	article	near_demo	far_demo	possessive	translation
e-mailadres	het	dit	dat	ons	email address
account	het	dit	dat	ons	account
wachtwoord	het	dit	dat	ons	password
bericht	het	dit	dat	ons	message
e-mail	de	deze	die	onze	email
website	de	deze	die	onze	website
pagina	de	deze	die	onze	page
gebruiker	de	deze	die	onze	user
naam	de	deze	die	onze	name
adres	het	dit	dat	ons	address
telefoon	de	deze	die	onze	telephone
computer	de	deze	die	onze	computer
laptop	de	deze	die	onze	laptop
tablet	de	deze	die	onze	tablet
app	de	deze	die	onze	app
programma	het	dit	dat	ons	program
bestand	het	dit	dat	ons	file
map	de	deze	die	onze	folder
mapje	het	dit	dat	ons	folder (small)/subfolder
link	de	deze	die	onze	link
afbeelding	de	deze	die	onze	image
foto	de	deze	die	onze	photo
video	de	deze	die	onze	video
muziek	de	deze	die	onze	music
geluid	het	dit	dat	ons	sound
server	de	deze	die	onze	server
netwerk	het	dit	dat	ons	network
systeem	het	dit	dat	ons	system
huis	het	dit	dat	ons	house
kamer	de	deze	die	onze	room
keuken	de	deze	die	onze	kitchen
badkamer	de	deze	die	onze	bathroom
slaapkamer	de	deze	die	onze	bedroom
woonkamer	de	deze	die	onze	living room
deur	de	deze	die	onze	door
raam	het	dit	dat	ons	window
muur	de	deze	die	onze	wall
vloer	de	deze	die	onze	floor
plafond	het	dit	dat	ons	ceiling
lamp	de	deze	die	onze	lamp
licht	het	dit	dat	ons	light
stoel	de	deze	die	onze	chair
bank	de	deze	die	onze	sofa
bed	het	dit	dat	ons	bed
kast	de	deze	die	onze	cupboard/closet
tafel	de	deze	die	onze	table
tafelblad	het	dit	dat	ons	tabletop
tapijt	het	dit	dat	ons	carpet
schilderij	het	dit	dat	ons	painting
kop	de	deze	die	onze	cup (cup/mug)
kopje	het	dit	dat	ons	cup (small)
glas	het	dit	dat	ons	glass
bord	het	dit	dat	ons	plate
mes	het	dit	dat	ons	knife
vork	de	deze	die	onze	fork
lepel	de	deze	die	onze	spoon
kom	de	deze	die	onze	bowl
fles	de	deze	die	onze	bottle
pan	de	deze	die	onze	pan
pot	de	deze	die	onze	pot
oven	de	deze	die	onze	oven
koelkast	de	deze	die	onze	fridge
vriezer	de	deze	die	onze	freezer
magnetron	de	deze	die	onze	microwave
waterkoker	de	deze	die	onze	kettle
koffiezetapparaat	het	dit	dat	ons	coffee maker
papier	het	dit	dat	ons	paper
pen	de	deze	die	onze	pen
potlood	het	dit	dat	ons	pencil
gum	de	deze	die	onze	eraser
schrift	het	dit	dat	ons	notebook
boek	het	dit	dat	ons	book
bladzijde	de	deze	die	onze	page (of a book)
krant	de	deze	die	onze	newspaper
tijdschrift	het	dit	dat	ons	magazine
brief	de	deze	die	onze	letter
kaart	de	deze	die	onze	card/map (context)
kaartje	het	dit	dat	ons	ticket/card (small)
ticket	het	dit	dat	ons	ticket
printer	de	deze	die	onze	printer
bureau	het	dit	dat	ons	desk/office (context)
agenda	de	deze	die	onze	diary/agenda
school	de	deze	die	onze	school
klas	de	deze	die	onze	class
student	de	deze	die	onze	student
leerling	de	deze	die	onze	pupil
docent	de	deze	die	onze	teacher/lecturer
leraar	de	deze	die	onze	teacher
universiteit	de	deze	die	onze	university
opdracht	de	deze	die	onze	assignment
toets	de	deze	die	onze	test/quiz
examen	het	dit	dat	ons	exam
cijfer	het	dit	dat	ons	grade/mark
vraag	de	deze	die	onze	question
antwoord	het	dit	dat	ons	answer
voorbeeld	het	dit	dat	ons	example
regel	de	deze	die		rule
taal	de	deze	die		language
zin	de	deze	die		sentence
woord	het	dit	dat	ons	word
lidwoord	het	dit	dat	ons	article (grammar)
werkwoord	het	dit	dat	ons	verb
naamwoord	het	dit	dat	ons	noun
uitspraak	de	deze	die	onze	pronunciation
betekenis	de	deze	die	onze	meaning
vertaling	de	deze	die	onze	translation
fout	de	deze	die	onze	mistake
correctie	de	deze	die	onze	correction
uitleg	de	deze	die	onze	explanation
oefening	de	deze	die	onze	exercise
spel	het	dit	dat	ons	game
spelletje	het	dit	dat	ons	little game
score	de	deze	die	onze	score
niveau	het	dit	dat	ons	level
dag	de	deze	die	onze	day
nacht	de	deze	die	onze	night
ochtend	de	deze	die	onze	morning
middag	de	deze	die	onze	afternoon
avond	de	deze	die		evening
week	de	deze	die		week
maand	de	deze	die		month
jaar	het	dit	dat	ons	year
uur	het	dit	dat	ons	hour
minuut	de	deze	die		minute
seconde	de	deze	die		second
moment	het	dit	dat	ons	moment
datum	de	deze	die		date
kalender	de	deze	die		calendar
afspraak	de	deze	die		appointment
vergadering	de	deze	die		meeting
les	de	deze	die		lesson
stad	de	deze	die		city
dorp	het	dit	dat	ons	village
land	het	dit	dat	ons	country
straat	de	deze	die		street
weg	de	deze	die		road
plein	het	dit	dat	ons	square
park	het	dit	dat	ons	park
station	het	dit	dat	ons	station
perron	het	dit	dat	ons	platform
halte	de	deze	die		stop
vliegveld	het	dit	dat	ons	airport
luchthaven	de	deze	die		airport
vliegtuig	het	dit	dat	ons	airplane
schip	het	dit	dat	ons	ship
boot	de	deze	die		boat
trein	de	deze	die		train
bus	de	deze	die		bus
auto	de	deze	die		car
fiets	de	deze	die		bicycle
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
