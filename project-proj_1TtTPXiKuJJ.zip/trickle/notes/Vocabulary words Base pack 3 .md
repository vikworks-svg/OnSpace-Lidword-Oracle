lemma	article	near_demo	far_demo	possessive	translation
baan	de	deze	die	onze	job
beroep	het	dit	dat	ons	profession
collega	de	deze	die	onze	colleague
bedrijf	het	dit	dat	ons	company
vergadering	de	deze	die	onze	meeting
project	het	dit	dat	ons	project
opdracht	de	deze	die	onze	assignment
salaris	het	dit	dat	ons	salary
vacature	de	deze	die	onze	job vacancy
contract	het	dit	dat	ons	contract
arbeidsovereenkomst	de	deze	die	onze	employment contract
werkdag	de	deze	die	onze	workday
werkdruk	de	deze	die	onze	workload
werkplek	de	deze	die	onze	workplace
pauze	de	deze	die	onze	break
promotie	de	deze	die	onze	promotion
werknemer	de	deze	die	onze	employee
werkgever	de	deze	die	onze	employer
team	het	dit	dat	ons	team
leidinggevende	de	deze	die	onze	manager/supervisor
overleg	het	dit	dat	ons	consultation/meeting
planning	de	deze	die	onze	planning/schedule
deadline	de	deze	die	onze	deadline
agenda	de	deze	die	onze	agenda/diary
notulen	de	deze	die	onze	minutes (meeting notes)
feedback	de	deze	die	onze	feedback
training	de	deze	die	onze	training
opleiding	de	deze	die	onze	education program
examen	het	dit	dat	ons	exam
cijfer	het	dit	dat	ons	grade/mark
toets	de	deze	die	onze	test/quiz
huiswerk	het	dit	dat	ons	homework
klas	de	deze	die	onze	class
lokaal	het	dit	dat	ons	classroom
les	de	deze	die	onze	lesson
docent	de	deze	die	onze	teacher/lecturer
leraar	de	deze	die	onze	teacher
student	de	deze	die	onze	student
cursist	de	deze	die	onze	course participant
cursus	de	deze	die	onze	course
niveau	het	dit	dat	ons	level
vaardigheid	de	deze	die	onze	skill
grammatica	de	deze	die	onze	grammar
woordenboek	het	dit	dat	ons	dictionary
vertaling	de	deze	die	onze	translation
uitspraak	de	deze	die	onze	pronunciation
betekenis	de	deze	die	onze	meaning
voorbeeld	het	dit	dat	ons	example
fout	de	deze	die	onze	mistake
tip	de	deze	die	onze	tip
regel	de	deze	die	onze	rule
uitzondering	de	deze	die	onze	exception
verbetering	de	deze	die	onze	improvement
vraag	de	deze	die	onze	question
antwoord	het	dit	dat	ons	answer
optie	de	deze	die	onze	option
keuze	de	deze	die	onze	choice
verschil	het	dit	dat	ons	difference
overeenkomst	de	deze	die	onze	similarity/agreement
zin	de	deze	die	onze	sentence
woord	het	dit	dat	ons	word
tekst	de	deze	die	onze	text
alinea	de	deze	die	onze	paragraph
brief	de	deze	die	onze	letter
formulier	het	dit	dat	ons	form
bijlage	de	deze	die	onze	attachment
bericht	het	dit	dat	ons	message
scherm	het	dit	dat	ons	screen
toetsenbord	het	dit	dat	ons	keyboard
muis	de	deze	die	onze	mouse (computer)
laptop	de	deze	die	onze	laptop
computer	de	deze	die	onze	computer
verbinding	de	deze	die	onze	connection
internet	het	dit	dat	ons	internet
wachtwoord	het	dit	dat	ons	password
gebruikersnaam	de	deze	die	onze	username
account	het	dit	dat	ons	account
instelling	de	deze	die	onze	setting
update	de	deze	die	onze	update
foutmelding	de	deze	die	onze	error message
knop	de	deze	die	onze	button
icoon	het	dit	dat	ons	icon
link	de	deze	die	onze	link
website	de	deze	die	onze	website
pagina	de	deze	die	onze	page
bestand	het	dit	dat	ons	file
map	de	deze	die	onze	folder
cloud	de	deze	die	onze	cloud
opslag	de	deze	die	onze	storage
privacy	de	deze	die	onze	privacy
toestemming	de	deze	die	onze	consent/permission
beveiliging	de	deze	die	onze	security
risico	het	dit	dat	ons	risk
melding	de	deze	die	onze	notification
voorkeur	de	deze	die	onze	preference
taal	de	deze	die	onze	language
geluid	het	dit	dat	ons	sound
camera	de	deze	die	onze	camera
microfoon	de	deze	die	onze	microphone
auto	de	deze	die	onze	car
fiets	de	deze	die	onze	bicycle
trein	de	deze	die	onze	train
bus	de	deze	die	onze	bus
station	het	dit	dat	ons	station
perron	het	dit	dat	ons	platform (train)
halte	de	deze	die	onze	stop
kaartje	het	dit	dat	ons	ticket
abonnement	het	dit	dat	ons	subscription
vertraging	de	deze	die	onze	delay
vertrektijd	de	deze	die	onze	departure time
aankomst	de	deze	die	onze	arrival
reis	de	deze	die	onze	journey
route	de	deze	die	onze	route
file	de	deze	die	onze	traffic jam
rijbewijs	het	dit	dat	ons	driver's license
parkeerbon	de	deze	die	onze	parking ticket
tol	de	deze	die	onze	toll
ov-chipkaart	de	deze	die	onze	public transport card
spoor	het	dit	dat	ons	track/rail
conducteur	de	deze	die	onze	conductor
chauffeur	de	deze	die	onze	driver
gemeente	de	deze	die	onze	municipality
loket	het	dit	dat	ons	service desk/counter
afspraak	de	deze	die	onze	appointment
afspraakbevestiging	de	deze	die	onze	appointment confirmation
aanvraag	de	deze	die	onze	application (request)
aangifte	de	deze	die	onze	declaration/tax return/report
belasting	de	deze	die	onze	tax
toeslag	de	deze	die	onze	allowance/benefit
zorgtoeslag	de	deze	die	onze	healthcare benefit
huurtoeslag	de	deze	die	onze	rent benefit
inkomen	het	dit	dat	ons	income
loonstrookje	het	dit	dat	ons	payslip
bank	de	deze	die	onze	bank
overschrijving	de	deze	die	onze	transfer
machtiging	de	deze	die	onze	authorization (mandate)
incasso	de	deze	die	onze	direct debit
zorgverzekering	de	deze	die	onze	health insurance
huisarts	de	deze	die	onze	general practitioner
recept	het	dit	dat	ons	prescription/recipe
doorverwijzing	de	deze	die	onze	referral
spoed	de	deze	die	onze	emergency/urgency
klacht	de	deze	die	onze	complaint
pijn	de	deze	die	onze	pain
koorts	de	deze	die	onze	fever
onderzoek	het	dit	dat	ons	examination/research
behandeling	de	deze	die	onze	treatment
bijwerking	de	deze	die	onze	side effect
allergie	de	deze	die	onze	allergy
tijd	de	deze	die	onze	time
bibliotheek	de	deze	die	onze	library
boekwinkel	de	deze	die	onze	bookshop
kantoor	het	dit	dat	ons	office
vergunning	de	deze	die	onze	permit
rekening	de	deze	die	onze	bill/account statement
bon	de	deze	die	onze	receipt
pinautomaat	de	deze	die	onze	ATM
portemonnee	de	deze	die	onze	wallet
sleutel	de	deze	die	onze	key
sleutelbos	de	deze	die	onze	keyring
rugzak	de	deze	die	onze	backpack
tas	de	deze	die	onze	bag
koffer	de	deze	die	onze	suitcase
paspoort	het	dit	dat	ons	passport
identiteitskaart	de	deze	die	onze	ID card
verzekering	de	deze	die	onze	insurance
dokter	de	deze	die	onze	doctor
tandarts	de	deze	die	onze	dentist
afspraakkaartje	het	dit	dat	ons	appointment card
ziekenhuis	het	dit	dat	ons	hospital
aparte kamer	de	deze	die	onze	private room
receptie	de	deze	die	onze	reception
wachtruimte	de	deze	die	onze	waiting room
thermostaat	de	deze	die	onze	thermostat
verwarming	de	deze	die	onze	heating
airco	de	deze	die	onze	air conditioner
raamdecoratie	de	deze	die	onze	window covering
trap	de	deze	die	onze	stairs
lift	de	deze	die	onze	elevator
balkon	het	dit	dat	ons	balcony
zolder	de	deze	die	onze	attic
kelder	de	deze	die	onze	basement
schuur	de	deze	die	onze	shed
garage	de	deze	die	onze	garage
tuin	de	deze	die	onze	garden
grasmaaier	de	deze	die	onze	lawn mower
gieter	de	deze	die	onze	watering can
barbecue	de	deze	die	onze	barbecue (grill)
vuilnisbak	de	deze	die	onze	trash bin
recycling	het	dit	dat	ons	recycling
pakket	het	dit	dat	ons	package
bezorger	de	deze	die	onze	delivery person
postbode	de	deze	die	onze	mail carrier
brievenbus	de	deze	die	onze	mailbox (slot)
stoplicht	het	dit	dat	ons	traffic light
rotonde	de	deze	die	onze	roundabout
kruispunt	het	dit	dat	ons	intersection
zebra	het	dit	dat	ons	crosswalk
boete	de	deze	die	onze	fine (penalty)
politie	de	deze	die	onze	police
brandweer	de	deze	die	onze	fire brigade
ambulance	de	deze	die	onze	ambulance
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
