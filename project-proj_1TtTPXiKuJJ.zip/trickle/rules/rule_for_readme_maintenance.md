When updating the Lidwoord Oracle project
- Always check if README.md needs updates after significant changes
- Update feature lists when adding new games or functionality
- Maintain version history and creation dates
- Keep technical specifications current with implementation
- Document any new game mechanics or scoring systems