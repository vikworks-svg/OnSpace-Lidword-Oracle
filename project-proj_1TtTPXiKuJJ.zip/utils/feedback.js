const correctFeedback = [
  "De chaos kiest jou.", "Correct.", "Clean hit.", "Nice.", "Nailed it.", "On point.",
  "Crisp.", "Locked in.", "Certified.", "Textbook.", "Chef's kiss.", "Dialed.",
  "Approved.", "Bullseye.", "Flawless.", "Aced it.", "Sharp.", "That's it.",
  "Green light.", "Mint.", "Juist.", "Lekker bezig.", "Strak.", "Netjes.",
  "Helemaal goed.", "Raak.", "Gefixt.", "Mooi zo.", "Dat is 'm.", "Klopt.",
  "Bingo.", "Strak werk.", "Spot on.", "Goud.", "Prima.", "Lekker.",
  "Hoppakee.", "Keurig.", "Bevestigd."
];

const wrongFeedback = [
  "Cute. Try again.", "Nope.", "Miss.", "One more.", "Not today.", "Close, but no.",
  "Almost.", "Try again.", "Missed it.", "Red light.", "Off by one.", "Not quite.",
  "Wrong timeline.", "Reset and go.", "Whiff.", "Do-over.", "Missed the memo.",
  "Keep going.", "Reroll.", "Try once more.", "Doe normaal.", "Mis.", "Bijna.",
  "Nog een keer.", "Probeer opnieuw.", "Niet helemaal.", "Helaas.", "Nee.",
  "Niet vandaag.", "Foutje.", "Close, maar nee.", "Jammer joh.", "Mwah, nee.",
  "Nog niet.", "Nee hoor.", "Oeps.", "Mispoes.", "Nogmaals.", "Even opnieuw.",
  "Terug naar start."
];

function getRandomFeedback(isCorrect) {
  try {
    const pool = isCorrect ? correctFeedback : wrongFeedback;
    const randomIndex = Math.floor(Math.random() * pool.length);
    return pool[randomIndex];
  } catch (error) {
    console.error('Error getting random feedback:', error);
    return isCorrect ? 'Correct!' : 'Try again!';
  }
}