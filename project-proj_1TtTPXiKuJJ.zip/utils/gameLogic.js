// Game logic utilities

// Get weighted word selection (prioritize nemesis, exclude mastered)
async function getWeightedWords(count = 10, excludeMastered = true) {
  try {
    const words = await trickleListObjects('word', 100);
    const progress = await trickleListObjects('progress', 100);
    
    const availableWords = [];
    
    words.items.forEach(word => {
      const wordProgress = progress.items.find(p => p.objectData.wordId === word.objectId);
      
      if (excludeMastered && wordProgress?.objectData.isMastered) {
        return; // Skip mastered words
      }
      
      const weight = wordProgress?.objectData.isNemesis ? 3 : 1;
      
      // Add word multiple times based on weight
      for (let i = 0; i < weight; i++) {
        availableWords.push({ ...word.objectData, id: word.objectId });
      }
    });
    
    // Shuffle and return requested count
    const shuffled = availableWords.sort(() => Math.random() - 0.5);
    return shuffled.slice(0, count);
  } catch (error) {
    console.error('Error getting weighted words:', error);
    return [];
  }
}

// Record attempt and update progress
async function recordAttempt(wordId, activityType, correct, response) {
  try {
    // Record the attempt
    await trickleCreateObject('attempt', {
      wordId,
      activityType,
      correct,
      response,
      timestamp: new Date().toISOString()
    });
    
    // Update or create progress
    const progressList = await trickleListObjects('progress', 100);
    const existing = progressList.items.find(p => p.objectData.wordId === wordId);
    
    if (existing) {
      const data = existing.objectData;
      const newCorrectStreak = correct ? data.correctStreak + 1 : 0;
      const newTotalCorrect = correct ? data.totalCorrect + 1 : data.totalCorrect;
      const newTotalWrong = correct ? data.totalWrong : data.totalWrong + 1;
      
      // Check if word becomes mastered (3+ correct in a row)
      const isMastered = newCorrectStreak >= 3;
      
      // Check if word becomes nemesis (wrong >= right and >= 2 wrong)
      const isNemesis = !isMastered && newTotalWrong >= newTotalCorrect && newTotalWrong >= 2;
      
      await trickleUpdateObject('progress', existing.objectId, {
        correctStreak: newCorrectStreak,
        totalCorrect: newTotalCorrect,
        totalWrong: newTotalWrong,
        isMastered,
        isNemesis
      });
    } else {
      // Create new progress entry
      await trickleCreateObject('progress', {
        wordId,
        correctStreak: correct ? 1 : 0,
        totalCorrect: correct ? 1 : 0,
        totalWrong: correct ? 0 : 1,
        isMastered: false,
        isNemesis: false
      });
    }
  } catch (error) {
    console.error('Error recording attempt:', error);
  }
}

// Generate demonstrative options for dit/dat game
function getDemonstrativeOptions(article, proximity) {
  const correct = getCorrectDemonstrative(article, proximity);
  
  const allOptions = ['dit', 'dat', 'deze', 'die'];
  const incorrect = allOptions.filter(opt => opt !== correct);
  
  return { correct, allOptions: allOptions.sort(() => Math.random() - 0.5) };
}

function getCorrectDemonstrative(article, proximity) {
  if (article === 'het') {
    return proximity === 'NEAR' ? 'dit' : 'dat';
  } else {
    return proximity === 'NEAR' ? 'deze' : 'die';
  }
}