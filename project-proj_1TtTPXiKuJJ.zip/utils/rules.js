const grammarRules = [
  "Diminutives end in -je and take 'het': het meisje, het kopje",
  "Abstract endings -heid, -ing, -te, -nis take 'de'",
  "Borrowed endings -isme, -ment, -um often take 'het'",
  "In compounds, the last word determines the article",
  "Languages and metals take 'het': het Engels, het goud",
  "For adjectives with de-words: add -e (de rode tafel)",
  "For adjectives with het-words (no article): no -e (een klein huis)",
  "With het/demonstratives/plurals: add -e (het kleine huis)",
  "Remember: de → deze/die (E sound), het → dit/dat (T sound)",
  "Memorize common exceptions - there are always some!"
];

function getRandomRule() {
  try {
    const randomIndex = Math.floor(Math.random() * grammarRules.length);
    return grammarRules[randomIndex];
  } catch (error) {
    console.error('Error getting random rule:', error);
    return 'Click to view all grammar rules';
  }
}