const seedWords = [
  {lemma:"e-mailadres",article:"het",note:"Compound; head = adres → het.",gloss_en:"email address"},
  {lemma:"account",article:"het",note:"Loanword; common gender (de) is also heard; we use het? — For consistency here: treat as het only if your data says het. If unsure, set to de and mark 'memorize'.",gloss_en:"account"},
  {lemma:"wachtwoord",article:"het",note:"Compound; head = woord (het) → het.",gloss_en:"password"},
  {lemma:"bericht",article:"het",note:"Neuter; memorize.",gloss_en:"message"},
  {lemma:"e-mail",article:"de",note:"Common gender (de). Memorize.",gloss_en:"email"},
  {lemma:"website",article:"de",note:"Common gender (de). Memorize.",gloss_en:"website"},
  {lemma:"pagina",article:"de",note:"Common gender (de). Memorize.",gloss_en:"page"},
  {lemma:"gebruiker",article:"de",note:"Common gender (de). Memorize.",gloss_en:"user"},
  {lemma:"naam",article:"de",note:"Common gender (de). Memorize.",gloss_en:"name"},
  {lemma:"adres",article:"het",note:"Neuter; memorize.",gloss_en:"address"},
  {lemma:"telefoon",article:"de",note:"Common gender (de). Memorize.",gloss_en:"telephone"},
  {lemma:"computer",article:"de",note:"Common gender (de). Memorize.",gloss_en:"computer"},
  {lemma:"laptop",article:"de",note:"Loanword; common gender (de). Memorize.",gloss_en:"laptop"},
  {lemma:"tablet",article:"de",note:"Common gender (de). Memorize.",gloss_en:"tablet"},
  {lemma:"app",article:"de",note:"Common gender (de). Memorize.",gloss_en:"app"},
  {lemma:"programma",article:"het",note:"Neuter; memorize.",gloss_en:"program"},
  {lemma:"bestand",article:"het",note:"Neuter; memorize.",gloss_en:"file"},
  {lemma:"map",article:"de",note:"Common gender (de). Memorize.",gloss_en:"folder"},
  {lemma:"mapje",article:"het",note:"Diminutive (-je) → het.",gloss_en:"little folder"},
  {lemma:"link",article:"de",note:"Common gender (de). Memorize.",gloss_en:"link"},
  {lemma:"afbeelding",article:"de",note:"Abstract ending -ing → de.",gloss_en:"image"},
  {lemma:"foto",article:"de",note:"Common gender (de). Memorize.",gloss_en:"photo"},
  {lemma:"video",article:"de",note:"Common gender (de). Memorize.",gloss_en:"video"},
  {lemma:"muziek",article:"de",note:"Common gender (de). Memorize.",gloss_en:"music"},
  {lemma:"geluid",article:"het",note:"Neuter; memorize.",gloss_en:"sound"},
  {lemma:"server",article:"de",note:"Common gender (de). Memorize.",gloss_en:"server"},
  {lemma:"netwerk",article:"het",note:"Neuter; memorize.",gloss_en:"network"},
  {lemma:"systeem",article:"het",note:"Neuter; memorize.",gloss_en:"system"},
  {lemma:"huis",article:"het",note:"Neuter; memorize.",gloss_en:"house"},
  {lemma:"kamer",article:"de",note:"Common gender (de). Memorize.",gloss_en:"room"}
];

// Initialize seed words in database
async function initializeWords() {
  try {
    for (const word of seedWords) {
      await trickleCreateObject('word', word);
    }
  } catch (error) {
    console.error('Error initializing words:', error);
  }
}