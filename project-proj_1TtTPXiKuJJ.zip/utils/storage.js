// Local storage utilities for offline functionality
const STORAGE_KEYS = {
  WORDS: 'lidwoord_words',
  ATTEMPTS: 'lidwoord_attempts', 
  PROGRESS: 'lidwoord_progress',
  DAILY_CHALLENGE: 'lidwoord_daily_challenge',
  APP_VERSION: 'lidwoord_app_version'
};

// Initialize app data
async function initializeData() {
  try {
    const version = localStorage.getItem(STORAGE_KEYS.APP_VERSION);
    if (!version) {
      await initializeWords();
      localStorage.setItem(STORAGE_KEYS.APP_VERSION, '1.0.0');
    }
  } catch (error) {
    console.error('Error initializing data:', error);
  }
}

// Calculate dashboard statistics
async function calculateStats() {
  try {
    const progressData = await trickleListObjects('progress', 100);
    const attempts = await trickleListObjects('attempt', 100);
    
    const totalWords = seedWords.length;
    const nemesisCount = progressData.items.filter(p => p.objectData.isNemesis).length;
    
    let correctAttempts = 0;
    let totalAttempts = 0;
    
    attempts.items.forEach(attempt => {
      totalAttempts++;
      if (attempt.objectData.correct) correctAttempts++;
    });
    
    const accuracy = totalAttempts > 0 ? Math.round((correctAttempts / totalAttempts) * 100) : 0;
    
    return {
      dayStreak: 0, // TODO: Implement streak calculation
      totalWords,
      dueForReview: nemesisCount,
      accuracy
    };
  } catch (error) {
    console.error('Error calculating stats:', error);
    return { dayStreak: 0, totalWords: 0, dueForReview: 0, accuracy: 0 };
  }
}

// Load nemesis words
async function loadNemesisWords() {
  try {
    const progressData = await trickleListObjects('progress', 100);
    const nemesis = progressData.items.filter(p => p.objectData.isNemesis);
    
    const nemesisWords = [];
    for (const progress of nemesis.slice(0, 10)) {
      const words = await trickleListObjects('word', 100);
      const word = words.items.find(w => w.objectId === progress.objectData.wordId);
      if (word) nemesisWords.push(word.objectData);
    }
    
    return nemesisWords;
  } catch (error) {
    console.error('Error loading nemesis words:', error);
    return [];
  }
}