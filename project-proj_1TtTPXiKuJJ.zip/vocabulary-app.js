class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--bg)]">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-[var(--text)] mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function VocabularyApp() {
  try {
    const [packs, setPacks] = React.useState([]);
    const [userStats, setUserStats] = React.useState({ streak: 0, accuracy: 0 });

    React.useEffect(() => {
      loadVocabularyPacks();
      loadUserStats();
    }, []);

    const loadVocabularyPacks = async () => {
      try {
        const packsData = await trickleListObjects('vocabulary_pack', 50);
        const sortedPacks = packsData.items
          .filter(pack => pack.objectData.is_active)
          .sort((a, b) => a.objectData.sort_order - b.objectData.sort_order);
        
        const packsWithStatus = await Promise.all(sortedPacks.map(async (pack) => {
          const isUnlocked = await checkPackUnlocked(pack);
          return { ...pack, isUnlocked };
        }));
        
        setPacks(packsWithStatus);
      } catch (error) {
        console.error('Error loading vocabulary packs:', error);
      }
    };

    const loadUserStats = async () => {
      try {
        const attempts = await trickleListObjects('attempt', 1000);
        const correctAttempts = attempts.items.filter(a => a.objectData.correct).length;
        const accuracy = attempts.items.length > 0 ? Math.round((correctAttempts / attempts.items.length) * 100) : 0;
        
        setUserStats({ streak: 5, accuracy });
      } catch (error) {
        console.error('Error loading user stats:', error);
      }
    };

    const checkPackUnlocked = async (pack) => {
      const data = pack.objectData;
      
      if (data.unlock_type === 'default') return true;
      if (data.unlock_type === 'streak') return userStats.streak >= data.unlock_value;
      if (data.unlock_type === 'accuracy') return userStats.accuracy >= data.unlock_value;
      
      return false;
    };

    const getCategoryIcon = (category) => {
      const icons = {
        Technology: 'cpu',
        Home: 'home',
        Food: 'utensils'
      };
      return icons[category] || 'book';
    };

    return (
      <div className="min-h-screen bg-[var(--bg)]">
        <Header />
        
        <main className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-[var(--text)] mb-4">Vocabulary Packs</h1>
            <p className="text-[var(--muted)]">Unlock new vocabulary packs by reaching milestones</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {packs.map((pack, index) => (
              <div
                key={index}
                className={`card transition-colors ${
                  pack.isUnlocked
                    ? 'hover:border-[var(--accent)] cursor-pointer'
                    : 'opacity-60'
                }`}
                onClick={() => pack.isUnlocked && (window.location.href = `quickfire.html?pack=${pack.objectId}`)}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                    pack.isUnlocked ? 'bg-[var(--accent)]' : 'bg-[var(--border)]'
                  }`}>
                    <div className={`icon-${getCategoryIcon(pack.objectData.category)} text-xl ${
                      pack.isUnlocked ? 'text-[var(--accent-ink)]' : 'text-[var(--muted)]'
                    }`}></div>
                  </div>
                  {pack.isUnlocked ? (
                    <div className="icon-unlock text-lg text-[var(--accent)]"></div>
                  ) : (
                    <div className="icon-lock text-lg text-[var(--muted)]"></div>
                  )}
                </div>

                <h3 className="text-lg font-semibold text-[var(--text)] mb-2">{pack.objectData.name}</h3>
                <p className="text-[var(--muted)] text-sm mb-4">{pack.objectData.description}</p>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[var(--muted)]">{pack.objectData.word_count} words</span>
                  <span className={`px-2 py-1 rounded text-xs ${
                    pack.isUnlocked 
                      ? 'bg-[var(--accent)] text-[var(--accent-ink)]' 
                      : 'bg-[var(--border)] text-[var(--muted)]'
                  }`}>
                    {pack.objectData.category}
                  </span>
                </div>

                {!pack.isUnlocked && (
                  <div className="mt-4 pt-4 border-t border-[var(--border)]">
                    <p className="text-xs text-[var(--muted)]">🔒 {pack.objectData.unlock_requirement}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </main>
      </div>
    );
  } catch (error) {
    console.error('VocabularyApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <VocabularyApp />
  </ErrorBoundary>
);